const readArray =
  [
    {name:"Domination of SonWukong"  },
    {name:"The Pantheon"},
    {name:"Loki's Ire" },
    {name:"Odyssey" }
  ]

Template.read.helpers(
 {
   readArray
  }
)
