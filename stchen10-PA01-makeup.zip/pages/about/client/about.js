const team =
  [
    {name:"Tim Hickey"    , email: "tjhickey@brandeis.edu" },
    {name:"Luyi Bai" , email: "kwipnc@brandeis.edu" }
  ];

Template.about.helpers(
 {
   team
 }
)
