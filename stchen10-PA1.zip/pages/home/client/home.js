const novelArray =
  [
    {name:"Domination of SonWukong"    , chapter: "Chapter 1" },
    {name:"The Pantheon" , chapter: "Chapter 2" },
    {name:"Loki's Ire" , chapter: "Chapter 3"},
    {name:"Odyssey", chapter: "Chapter 4" }
  ]

Template.home.helpers(
 {
   novelArray
  }
)
